ArenaSA Sprint One


Download the lastest exported zip file folder: ArenaSA_v1.zip
Within you will find "ArenaSA_v1.jar" simply double click to run the program.
Before continuing, Please take the time to read the instructions below.

NOTE: 
This program connects to a remote server so an internet connection is necessary for program functionality. 


� Getting Started with the program:
  -Create a new username and password: 
New users are automatically assigned a spectator role. 
This is the most basic role with the most basic permissions. 
A Spectator can only view current and past matches and cannot participate in matches. 
As a Spectator, you can petition to have your role changed by clicking the "Apply" Button in
the Bottom-Right corner of the interface. 

Applications to both the Operator & League Owner roles must be approved by an existing Operator
As such, the program comes with a default Operator role to allow for setting up your own
Operator login. 

The Default Login information is : Username:  Admin
                                   Password:  Password

Note that both User Names & Passwords are case sensitive.
Note Usernames are only allowed 1 Role at a time.

It is recommended that you First. Create your intented Admin account. Sign out. Log in as the default
Admin account mentioned aboved. Approve your created account as Operator. And then remove the Admin
Default for security purposes. 

After this step is complete. Using your new Operator Account. You can now Manage New Users Applications.
Allowing for the creation of any Role you wish.  
 
� Roles Explained: 
There are 5 Role Types: Spectator. Operator. League Owner. Player. Advertiser
Initially, a new User is given the role Spectator. As mentioned above. Spectator's have a limited
range of functionality within the program. 
- Operator:  This is the Administrative Role. From here Users, Games, & Arenas can be managed.
- League Owner: The Show Runner. From here Teams, Player Applications, Matches, Tournaments & Leagues can be managed.
- Player: Players can Apply to a Team, Join a League, or manaage the Leagues they are in.
- Advertiser: Currently this role lacks functionality. 
Eventually will allow for management of both Advertisements & balance. 



