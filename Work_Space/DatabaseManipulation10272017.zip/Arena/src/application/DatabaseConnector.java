package application;

import java.sql.*;
import java.util.Scanner;

public class DatabaseConnector
{
	private String databaseLink = "jdbc:mysql://localhost:3306/arenadatabase?autoReconnect=true&useSSL=false";
	private String databaseUser = "root";
	private String databasePassword = "#altf4ctrlf6f12!";

	//private String databaseUser = "root"; // Xampp Credentials
	//private String databasePassword = ""; // Xampp Credentials

	private Connection connection;
	private Statement statement;
	private ResultSet resultSet;

	static Main main = new Main();
	Scanner scanner = new Scanner(System.in);

	// Connects to the database
	public DatabaseConnector()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(databaseLink, databaseUser, databasePassword);
			System.out.println("Connection Successful");
			statement = connection.createStatement();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
	}


	public void makeNewUser()
	{
		String userName = null;
		String userPassword = null;

		String newUserQuery = "INSERT INTO users (userName, userPassword, userRoleID) "
				+ "VALUES (?, ?, 4)";
		try
		{
			System.out.println("Please enter the values of the new User:");

			System.out.println("Username: ");
			userName = scanner.nextLine();
			System.out.println("Userpassword: ");
			userPassword = scanner.nextLine();
			PreparedStatement preparedStatement = connection.prepareStatement(newUserQuery);
			preparedStatement.setString (1, userName);
			preparedStatement.setString (2, userPassword);

			// execute the preparedStatement
			preparedStatement.execute();
			getUsersInformation();

		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
	}
	public void DeleteUser()
	{
		String userID = null;
		String deleteUserQuery = "DELETE FROM users WHERE userID = '" + userID + "';";
		try
		{
			getUsersInformation();
			System.out.println("Enter User ID to delete");
			userID = scanner.nextLine();
			PreparedStatement preparedStatement = connection.prepareStatement(deleteUserQuery);

			preparedStatement.execute();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
	}
	public void getUsersInformation()
	{
		//predefined query to select all entries from a specific pre-defined table
		//String query = "SELECT * FROM users";
		String query = "SELECT user1.*, userroletype1.userRoleTypeName FROM users user1, userroletype userroletype1 WHERE user1.userRoleID = userroletype1.userRoleTypeID";
		try
		{
			resultSet = statement.executeQuery(query);
			System.out.println("Users");
			while(resultSet.next())
			{

				String id = resultSet.getString("userID");
				String name = resultSet.getString("userName");
				String password = resultSet.getString("userPassword");
				String roleTypeID = resultSet.getString("userRoleID");
				String roleTypeName = resultSet.getString("userRoleTypeName");

				System.out.println("User ID: " + id + " ");
				System.out.println("\t" + "Username: " + name);
				System.out.println("\t" + "Password: " + password + " ");
				System.out.println("\t" + "Role ID: " + roleTypeID + " Role Name: " + roleTypeName + "\n");
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
		main.BasicFunctionMenu();
	}
	public void getOperators()
	{
		String query = "SELECT user1.*, userroletype1.userRoleTypeName FROM users user1, userroletype userroletype1 WHERE user1.userRoleID = userroletype1.userRoleTypeID AND user1.userRoleID = 0";
		//String query = "select * from users WHERE userRoleID = 0";
		try
		{
			resultSet = statement.executeQuery(query);
			System.out.println("Operators");
			while(resultSet.next())
			{
				String id = resultSet.getString("userID");
				String name = resultSet.getString("userName");
				String password = resultSet.getString("userPassword");
				String roleType = resultSet.getString("userRoleID");

				System.out.println("User ID: " + id + " ");
				System.out.println("\t" + "Username: " + name);
				System.out.println("\t" + "Password: " + password + " ");
				System.out.println("\t" + "Role Type: " + roleType + " \n");
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
		main.BasicFunctionMenu();
	}

	public void MakeUserOperator()
	{
		try
		{
			System.out.println("Enter UserID to change Role Type:");
			String userIDToMakeOperator = scanner.nextLine();

			String makeUserOperatorQuery = "UPDATE users SET userRoleID = 0  WHERE userID = "+ userIDToMakeOperator + " and userRoleID = 4 ";

			PreparedStatement preparedStatement = connection.prepareStatement(makeUserOperatorQuery);
			preparedStatement.execute();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
		main.BasicFunctionMenu();
	}
	public void MakeUserLeagueOwner()
	{
		try
		{
			System.out.println("Enter UserID to change Role type to League Owner:");
			String userIDToMakeLeagueOwner = scanner.nextLine();

			String makeUserLeagueOwnerQuery = "UPDATE users SET userRoleID = 1  WHERE userID = "+ userIDToMakeLeagueOwner + " and userRoleID = 4 ";

			PreparedStatement preparedStatement = connection.prepareStatement(makeUserLeagueOwnerQuery);
			preparedStatement.execute();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
		main.BasicFunctionMenu();
	}
	public void MakeUserAdvertiser()
	{
		try
		{
			System.out.println("Enter UserID to change Role type to Advertiser:");
			String userIDToMakeAdvertiser = scanner.nextLine();

			String makeUserAdvertiserQuery = "UPDATE users SET userRoleID = 2  WHERE userID = "+ userIDToMakeAdvertiser + " and userRoleID = 4 ";

			PreparedStatement preparedStatement = connection.prepareStatement(makeUserAdvertiserQuery);
			preparedStatement.execute();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
		main.BasicFunctionMenu();
	}
	public void makeUserPlayer()
	{
		try
		{
			System.out.println("Enter UserID to change Role type to Player:");
			String userIDToMakePlayer = scanner.nextLine();

			String makeUserPlayerQuery = "UPDATE users SET userRoleID = 3  WHERE userID = "+ userIDToMakePlayer + " and userRoleID = 4 ";

			PreparedStatement preparedStatement = connection.prepareStatement(makeUserPlayerQuery);
			preparedStatement.execute();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
		main.BasicFunctionMenu();
	}

	public void GetAllLeagues()
	{

	}
	public void ApplyToLeague()
	{

	}

	// Manipulation of Arenas
	public void GetAllArenas()
	{

	}
	public void CreateArena()
	{

	}
	public void DeleteArena()
	{

	}

	// Manipulation of Games
	public void createGame()
	{
		// Initialize relevant strings
		String gameName = null;
		String gameDesc = null;

		// This is the base sql Query statement
		String newGameQuery = "INSERT INTO game (GameName, GameDescription) Values (?,?)";
		try
		{
			// These methods modify the initial string values above
			System.out.println("Please enter Game Info Values");
			System.out.println("Game Name: ");
			gameName = scanner.nextLine();
			System.out.println("Game Desc: ");
			gameDesc = scanner.nextLine();

			//
			PreparedStatement preparedStatement = connection.prepareStatement(newGameQuery);
			preparedStatement.setString (1, gameName);
			preparedStatement.setString (2, gameDesc);

			// Call createGameScoreTable function
			UpdateGameScoreTableColumns();

			preparedStatement.execute();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
		main.BasicFunctionMenu();
	}

	//This function would be used to modify the GameScoreTable and add New Columns for a game
	public void UpdateGameScoreTableColumns()
	{
		try
		{
			//
			System.out.println("Enter in the amount of columns to add to the GameScoreTable");
			String GameScoreColumnsAmount = scanner.nextLine();
			int GameScoreColumnsAmountInt = Integer.parseInt(GameScoreColumnsAmount);	//Parses the String value into an int value. This is suppose to help stop scanner from eating inputs

			// This array has size of GameScoreColumnsAmountInt. It will hold the values of the column Names as well as their DataTypes
			String[] columnNames = new String[GameScoreColumnsAmountInt];

			//Saves Input into a string
			for (int i = 0; i < GameScoreColumnsAmountInt; i++)
			{
				System.out.println("Enter Name of column" + (i + 1) + " Followed By the Column Datatype");
				columnNames[i] = scanner.nextLine();
			}

			String addColumnsGameScoreTableQuery = "ALTER TABLE gamescoretable ADD (" + "\n";

			for(int j = 0; j < columnNames.length; j++)
			{
				addColumnsGameScoreTableQuery = addColumnsGameScoreTableQuery.concat(columnNames[j].toString() + " NOT NULL");

				if ((j + 1) != columnNames.length)
				{
					addColumnsGameScoreTableQuery = addColumnsGameScoreTableQuery.concat(", " + "\n");
				}

				//System.out.println("Is j equal to ColumnNames Array:" + IsJEqaulTOArrayLength(j, columnNames.length));
				//System.out.println("J: " + j + "Array Size: " + columnNames.length);
			}

			addColumnsGameScoreTableQuery = addColumnsGameScoreTableQuery.concat(")");

			//System.out.println(addColumnsGameScoreTableQuery);

			PreparedStatement preparedStatement = connection.prepareStatement(addColumnsGameScoreTableQuery);
			preparedStatement.execute();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
	}

	public void GetAllGames(boolean returnMenu)
	{
		String query = "SELECT * FROM game";
		try
		{
			resultSet = statement.executeQuery(query);
			System.out.println("Users");
			while(resultSet.next())
			{

				String gameid = resultSet.getString("GameID");
				String gameName = resultSet.getString("GameName");
				String gameDesc = resultSet.getString("GameDescription");

				System.out.println("Game ID: " + gameid + " " + gameName + ": " + gameDesc);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}

		if(returnMenu)
		{
			main.BasicFunctionMenu();
		}
	}
	public void DeleteGame()
	{
		try
		{
			GetAllGames(false);
			System.out.println("Please enter the GameID you wish to delete:");
			String deleteGameID = scanner.nextLine();
			String deleteGameQuery = "DELETE FROM game WHERE GameID = " + deleteGameID;

			PreparedStatement preparedStatement = connection.prepareStatement(deleteGameQuery);
			preparedStatement.execute();
		}
		catch(Exception ex)
		{
			System.out.println("Error: " + ex);
		}
		main.BasicFunctionMenu();
	}


}
