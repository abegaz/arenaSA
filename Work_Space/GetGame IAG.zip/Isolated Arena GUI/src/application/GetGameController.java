package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class GetGameController
{

    @FXML  private Button gameLoadBtn;
    @FXML private Label errorMsg;
    @FXML private TableView<GameData> getGameTable;
    @FXML private TableColumn<GameData, String> gameIDColumn;
    @FXML  private TableColumn<GameData, String> gameNameColumn;
    @FXML  private TableColumn<GameData, String> gameDescColumn;


    private ObservableList<GameData> gameDataArray;


    DatabaseConnector databaseConnector = new DatabaseConnector();

    @FXML
    void loadGameFromDatabase(ActionEvent event) throws SQLException
    {
		Connection connection = databaseConnector.getConnection();
		String getAllGameFromDatabase = "SELECT * FROM game";
	    gameDataArray = FXCollections.observableArrayList();
		try
		{
			ResultSet rs = connection.createStatement().executeQuery(getAllGameFromDatabase);
			while(rs.next())
			{
				String gameID = rs.getString("GameID");
				String gameName = rs.getString("GameName");
				String gameDesc = rs.getString("GameDescription");

				gameDataArray.add(new GameData (gameID, gameName, gameDesc));
			}

			gameIDColumn.setCellValueFactory(new PropertyValueFactory<>("gameID"));
			gameNameColumn.setCellValueFactory(new PropertyValueFactory<>("gameName"));
			gameDescColumn.setCellValueFactory(new PropertyValueFactory<>("gameDesc"));

			getGameTable.setItems(null);
			getGameTable.setItems(gameDataArray);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
    }

}
